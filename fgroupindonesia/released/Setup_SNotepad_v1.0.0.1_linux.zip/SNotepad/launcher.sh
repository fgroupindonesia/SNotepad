jre11.0.23/bin/java -jar ./SNotepad.jar
